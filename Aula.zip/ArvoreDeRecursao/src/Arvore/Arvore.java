package Arvore;

public class Arvore{

    
    public static int T(int n) {
        // Caso base: quando n � 1, o valor de T(1) � constante
        if (n <= 1) {
            return 1;
        }

        // Aplica a recorr�ncia T(n) = 4 * T(n / 4) + n
        int result = 2 * T(n / 2) + n;

        return result;
    }

    public static void main(String[] args) {
        
        int n = 600; 
        int result = T(n);

        // Exibe o resultado
        System.out.println("Resultado de T(" + n + ") = " + result);
    }
}
