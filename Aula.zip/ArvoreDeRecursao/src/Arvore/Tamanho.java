package Arvore;


public class Tamanho {

    Node root;

   
    public int size(Node node) {
        if (node == null) {
            return 0;
        }
        return 1 + size(node.esquerda) + size(node.direita);
    }


    public int height(Node node) {
        if (node == null) {
            return 0;
        }
        
        return 1 + Math.max(height(node.esquerda), height(node.direita));
    }

    public static void main(String[] args) {
        Tamanho tree = new Tamanho();
        
        
        tree.root = new Node(10);
        tree.root.esquerda = new Node(5);
        tree.root.direita = new Node(20);
        tree.root.direita.esquerda = new Node(30);
        tree.root.direita.esquerda.esquerda = new Node(15);
        tree.root.esquerda.esquerda = new Node(3);
        tree.root.esquerda.direita = new Node(7);

       
        int treeSize = tree.size(tree.root);
        System.out.println("O tamanho da �rvore �: " + treeSize);

      
        int treeHeight = tree.height(tree.root);
        System.out.println("A altura da �rvore �: " + treeHeight);
    }
}
