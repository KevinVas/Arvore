package Arvore;



public class Recursao {

    Node root;

    
    public int sumTree(Node node) {
        if (node == null) {
            return 0;
        }
       
        return node.value + sumTree(node.esquerda) + sumTree(node.direita);
    }

    
    public int size(Node node) {
        if (node == null) {
            return 0;
        }
        return 1 + size(node.esquerda) + size(node.direita);
    }

    public int height(Node node) {
        if (node == null) {
            return 0;
        }
       
        return 1 + Math.max(height(node.esquerda), height(node.direita));
    }

    public static void main(String[] args) {
        Recursao tree = new Recursao();
        
      
        tree.root = new Node(10);
        tree.root.esquerda = new Node(5);
        tree.root.direita = new Node(20);
        tree.root.direita.esquerda = new Node(30);
        tree.root.direita.esquerda.esquerda = new Node(15);
        tree.root.esquerda.esquerda = new Node(3);
        tree.root.esquerda.direita = new Node(7);
        tree.root.esquerda.direita.esquerda = new Node(9);
        tree.root.esquerda.direita.direita = new Node(14);
        tree.root.esquerda.direita.esquerda.esquerda = new Node(16);
        tree.root.esquerda.direita.esquerda.direita = new Node(18);
        tree.root.esquerda.direita.esquerda.direita.esquerda= new Node(21);
        tree.root.esquerda.direita.esquerda.direita.direita= new Node(23);
        tree.root.esquerda.direita.esquerda.esquerda.esquerda= new Node(32);
        tree.root.esquerda.direita.esquerda.esquerda.direita= new Node(35);
        tree.root.esquerda.direita.esquerda.esquerda.direita.direita= new Node(40);
        tree.root.esquerda.direita.esquerda.esquerda.direita.esquerda= new Node(41);
        tree.root.esquerda.direita.esquerda.esquerda.direita.direita.direita= new Node(50);
        tree.root.esquerda.direita.esquerda.esquerda.direita.direita.esquerda= new Node(51);
        tree.root.esquerda.direita.esquerda.esquerda.direita.esquerda.direita= new Node(52);
        tree.root.esquerda.direita.esquerda.esquerda.direita.esquerda.esquerda= new Node(60);
        tree.root.esquerda.direita.esquerda.esquerda.direita.esquerda.direita.direita= new Node(67);
        tree.root.esquerda.direita.esquerda.esquerda.direita.esquerda.direita.direita.esquerda= new Node(84);
        tree.root.esquerda.direita.esquerda.esquerda.direita.esquerda.direita.direita.direita= new Node(82);
        
        
        
        int totalSum = tree.sumTree(tree.root);
        System.out.println("A soma dos n�s �: " + totalSum);

       
        int treeSize = tree.size(tree.root);
        System.out.println("O tamanho da �rvore �: " + treeSize);

        
        int treeHeight = tree.height(tree.root);
        System.out.println("A altura da �rvore �: " + treeHeight);
    }
}
