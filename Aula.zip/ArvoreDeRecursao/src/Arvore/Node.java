package Arvore;

class Node {
    int value;
    Node esquerda, direita;

    
    public Node(int value) {
        this.value = value;
        esquerda = direita = null;
    }
}
